# AI Agent Team - Project Instructions (v5)

## Session Start Protocol (MANDATORY)

When starting ANY new conversation from this folder, ALWAYS read these files first before responding:

### 1. Core Files (C-core/)
- `C-core/project-brief.md` (What the business does)
- `C-core/voice-dna.md` (How the brand speaks)
- `C-core/icp-profile.md` (Who the target audience is)

### 2. Memory Files (M-memory/)
- `M-memory/learning-log.md` (What we've learned together)
- `M-memory/feedback.md` (Audience reactions and signals)
- `M-memory/decisions.md` (Strategic choices made)

### 3. Agent Definitions (A-agents/)
- `A-agents/copywriter-agent.md` (Content creation agent)
- `A-agents/gatekeeper-agent.md` (Quality review agent)
- `A-agents/tom-agent.md` (Your guide to the ABC-TOM system)

---

## How This Works

Claude Code automatically reads this file when you open a conversation from this folder.

The files above are your "memory". They persist between sessions. When you update them, future sessions will have that context.

**IMPORTANT:** Actually read these files before responding. Don't just acknowledge them. Scan C-core to understand the brand, check what's in A-agents, and review M-memory for context. This makes your responses relevant to THIS user's system.

---

## The ABC-TOM Loop (v5)

After completing significant work, close The Loop:

1. **New insight about what works?** Update `M-memory/learning-log.md`
2. **Received feedback?** Update `M-memory/feedback.md`
3. **Made a strategic decision?** Update `M-memory/decisions.md`
4. **Pattern strong enough to become a rule?** Promote it to `C-core/voice-dna.md`
5. **Research worth keeping?** Move it from `B-brain/INBOX/` to the right subfolder

The Loop is what makes the system compound. Every project that closes The Loop makes the next project better.

---

## Quick Commands

- "כתוב פוסט על [נושא]" - Creates content using your voice
- "תבדוק את האיכות" - Runs gatekeeper review
- "מה למדנו?" - Shows learning log summary
- "סגור את הלופ" - Runs The Loop (updates memory + promotes insights)
- `/tom [question]` - Get help from Tom on the ABC-TOM system

---

## Need Help?

Type `/tom` or ask any question about the ABC-TOM system.

Tom Agent knows the framework inside out and can help you:
- Understand what each folder is for
- Create new agents and skills
- Troubleshoot when things aren't working
- Navigate the bonus prompts
- Run The Loop

Works in Hebrew and English.

---

> **© Tom Even**
> Workshops: [www.getagents.today](https://www.getagents.today)
> Newsletter: [www.agentsandme.com](https://www.agentsandme.com)
