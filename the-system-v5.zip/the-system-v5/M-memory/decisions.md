# Decisions Log

Track key decisions you've made about your brand, content, and strategy. And why.

---

## The Boundary

This file captures strategic choices THE SYSTEM documents. Decisions start here in Memory. When a decision becomes a permanent brand principle, promote it to `C-core/project-brief.md` or `C-core/voice-dna.md`. That's The Loop.

---

## Why Track Decisions

> "A decision without context is just a rule. A decision with context is wisdom."

When you or your agents revisit old decisions, you need to know:
- What you decided
- Why you decided it
- What you considered
- Whether it's still valid

This prevents:
- Re-debating settled issues
- Forgetting why you do things a certain way
- Inconsistent choices over time

---

## How to Use This File

**When making decisions:** Log them here with rationale
**When questioning past choices:** Check here first
**The Loop:** Mature decisions get promoted to C-core. A decision that's held for 3+ months is probably a core principle.

---

## Decision Categories

### Brand Decisions
Choices about identity, positioning, voice.

### Content Decisions
Choices about what you create and how.

### Process Decisions
Choices about how you work.

### Strategic Decisions
Choices about direction and priorities.

---

## Decision Log

### Brand Decisions

| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| [Date] | [What you decided] | [Why] | [Active/Revisit/Deprecated] |

**Example:**
| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| 2024-01-15 | No emojis in headlines | Feels more professional, matches voice DNA | Active |
| 2024-01-10 | Always use "you" not "we" | More direct, creates connection | Active |

---

### Content Decisions

| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| [Date] | [What you decided] | [Why] | [Active/Revisit/Deprecated] |

**Example:**
| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| 2024-01-12 | LinkedIn posts max 300 words | Longer posts lose engagement | Active |
| 2024-01-08 | One CTA per post only | Multiple CTAs dilute action | Active |

---

### Process Decisions

| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| [Date] | [What you decided] | [Why] | [Active/Revisit/Deprecated] |

**Example:**
| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| 2024-01-14 | Gatekeeper reviews all content before publish | Quality control is non-negotiable | Active |
| 2024-01-11 | Version files as v1, v2, final | Need to track iterations | Active |

---

### Strategic Decisions

| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| [Date] | [What you decided] | [Why] | [Active/Revisit/Deprecated] |

**Example:**
| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| 2024-01-16 | Focus on LinkedIn over Twitter | Audience is more active there | Active |
| 2024-01-05 | Educational content over promotional | Builds trust, aligns with brand | Active |

---

## Decision Template

When logging a significant decision:

```markdown
## [Date] - [Decision Title]

**Decision:** [Clear statement of what was decided]

**Context:** [What prompted this decision]

**Options Considered:**
1. [Option A] - [Pros/cons]
2. [Option B] - [Pros/cons]
3. [Chosen option] - [Why this one]

**Rationale:** [The reasoning behind the choice]

**Implications:**
- [What this means for X]
- [What this means for Y]

**Review Date:** [When to revisit this decision]

**The Loop:** Is this ready to promote to C-core? [Yes/Not yet/N/A]

**Status:** Active / Revisit / Deprecated
```

---

## Quarterly Review Template

```markdown
## Q[X] Decision Review

### Decisions Still Valid
- [Decision] - Still working because [reason]

### Decisions to Revisit
- [Decision] - Questioning because [reason]

### Decisions to Promote to C-core (The Loop)
- [Decision] - Held for 3+ months, ready to become a core principle

### Decisions to Deprecate
- [Decision] - No longer relevant because [reason]

### New Decisions Needed
- [Topic] - Need to decide [what]
```

---

*Decisions age. Context helps them age well. Strong decisions graduate to C-core. That's The Loop.*

---

> **© Tom Even**
> Workshops & future dates: [www.getagents.today](https://www.getagents.today)
> Newsletter: [www.agentsandme.com](https://www.agentsandme.com)
